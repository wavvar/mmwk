#!/usr/bin/env bash
set -euo pipefail
PORT="${1:?usage: ./flash.sh <port>}"
: "${IDF_PATH:?source ESP-IDF export.sh first}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
python3 "$IDF_PATH/components/esptool_py/esptool/esptool.py"   --chip "esp32s3" --port "$PORT" --before default_reset --after hard_reset   write_flash 0x0 "mmwk_sensor_bridge_factory_v1.2.3.bin"
